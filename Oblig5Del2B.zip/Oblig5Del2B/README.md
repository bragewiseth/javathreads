Programmet krever to parametere
1. mappebane
2. antall flettetråder